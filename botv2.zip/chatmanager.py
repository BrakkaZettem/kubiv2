import json

chat_info = None

def load_chat_data(user):
	global chat_info
	with open(f"users/{user}/chat_log.json") as file:
		chat_info = json.load(file)

def save_chat_data(user):
    global chat_info
    with open(f"users/{user}/chat_log.json", "w") as file:
        json.dump(chat_info, file, indent=4)

#0 = false, 1 = true, 2 = user doesnt exist
def get_chat_mute_status(username, user):
	global chat_info
	load_chat_data(user)
	for chat in chat_info:
		if chat["username"] == username:
			return int(chat["muted"])
	return 2

def toggle_mute(username, user):
	global chat_info
	load_chat_data(user)
	#print(chat_info)
	print(username)
	for chat in chat_info:
		print(chat["username"])
		if str(chat["username"]) == str(username):
			print("THE EXACT SAME")
			print(chat["username"])
			chat["muted"] = not chat["muted"]
			save_chat_data(user)
			return True
	return False

def get_full_chat_log(user):
	global chat_info
	load_chat_data(user)
	return chat_info

def get_chat_log(username, user):
	global chat_info
	load_chat_data(user)
	for chat in chat_info:
		if str(chat["username"]) == str(username):
			return chat["session_content"]
	return None

def make_new_chat(username, user):
	global chat_info
	load_chat_data(user)
	new_chat = 	{
		"muted": False,
		"username" : username,
		"session_content": []
	}
	chat_info.append(new_chat)
	save_chat_data(user)

def append_to_chat(username, role, message, user):
	print("uessss")
	global chat_info
	load_chat_data(user)
	new_chat = {
                "role": role,
                "content": message
            }
	print(new_chat)
	for chat in chat_info:
		if str(chat["username"]) == str(username):
			chat["session_content"].append(new_chat)
			save_chat_data(user)
			return True
	return False


