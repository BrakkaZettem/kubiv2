import json
config = None

def load_config_data(user):
	global config
	with open(f"users/{user}/config.json") as file:
		config = json.load(file)

def save_config_data(user):
    global config
    with open(f"users/{user}/config.json", "w") as file:
        json.dump(config, file, indent=4)

def get_username_api_id_api_hash(user):
	global config
	load_config_data(user)
	return (config["username"], config["api_id"], config["api_hash"])

def get_payment_info(user):
	global config
	load_config_data(user)
	return config["payments"]

def set_payment_info(new_payment_info, user):
	global config
	load_config_data(user)
	config["payments"] = new_payment_info
	save_config_data(user)


#[btc], [ltc], [eth], [paypal], [price]
def get_default_response_info(user):
	global config
	load_config_data(user)
	temp_default_msg = config["responder"]["default_message"]
	default_msg = temp_default_msg.replace("[btc]", get_payment_info()["bitcoin"]).replace("[ltc]", get_payment_info()["litecoin"]).replace("[eth]", get_payment_info()["ethereum"]).replace("[paypal]", get_payment_info()["paypal"]).replace("[price]", get_payment_info()["price"])
	return config["responder"]["default_message"]

def set_efault_response_info(new_message, user):
	global config
	load_config_data(user)
	config["responder"]["default_message"] = new_message
	save_config_data(user)


def update_entire_config(new_config, user):
	global config
	load_config_data(user)
	config = new_config
	save_config_data(user)

def get_entire_config(user):
	global config
	load_config_data(user)
	return config