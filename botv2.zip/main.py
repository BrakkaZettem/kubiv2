from flask import Flask, render_template, request, redirect, url_for
from usermanager import *
from mutemanager import *
from configmanager import *
from postermanager import *

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html', usernames=get_user_list())

@app.route('/hello/<name>')
def hello_name(name):
    return f"<h1>Hello, {name}!</h1>"

@app.route('/togglemute/<user>/<username>')
def toggle_mute(user, username):
    toggle_mute_user(user, username)
    return redirect(f"/mute/{user}")

@app.route('/get_poster_info')
def get_poster_info():
    return get_all_configs()

@app.route('/poster/<user>')
def edit_config(user):
    return render_template('edit_config.html', config=get_poster_config(user), current_user=user)

@app.route('/poster/update/<user>', methods=['POST'])
def update_config(user):
    config_data = {
        "channel": "",
        "message": "",
        "message_freq": 1,
        "message2": "",
        "messafe2_freq": 5,
        "post_freq": 1000
    }
    config_data['channel'] = request.form['channel']
    config_data['message'] = request.form['message']
    config_data['message_freq'] = int(request.form['message_freq'])
    config_data['message2'] = request.form['message2']
    config_data['messafe2_freq'] = int(request.form['messafe2_freq'])
    config_data['post_freq'] = int(request.form['post_freq'])
    set_poster_config(user, config_data)

    return redirect(f"/poster/{user}")


@app.route('/mute/<user>')
def mute_menu(user):
    return render_template('mute_status.html', users=get_mute_list(user), current_user=user)

@app.route('/config/<userdir>')
def edit(userdir):
    return render_template('edit.html', user=get_entire_config(userdir), current_user=userdir)

@app.route('/update_config/<user>', methods=['POST'])
def update(user):
    user_data = {
        "username": "@yungplugobu",
        "api_id": "20001746",
        "api_hash": "ad25ff9fc57305256ab13ea27c611424",
        "payments": {
            "bitcoin": "kkr",
            "litecoin": "",
            "ethereum": "",
            "paypal": "",
            "price": ""
        },
        "responder": {
            "default_message": "From now on I am Hayden, I keep all my messages as short as possible and casual I say bro often, ...",
        }
    }
    user_data['username'] = request.form['username']
    user_data['api_id'] = request.form['api_id']
    user_data['api_hash'] = request.form['api_hash']
    user_data['payments']['bitcoin'] = request.form['bitcoin']
    user_data['payments']['litecoin'] = request.form['litecoin']
    user_data['payments']['ethereum'] = request.form['ethereum']
    user_data['payments']['paypal'] = request.form['paypal']
    user_data['payments']['price'] = request.form['price']
    user_data['responder']['default_message'] = request.form['default_message']
    update_entire_config(user_data, user)
    return redirect(f"/config/{user}")

if __name__ == '__main__':
    app.run(debug=True)



if __name__ == '__main__':
    app.run(debug=True)
