import json
import os

def get_poster_config(user):
	with open(f"users/{user}/postconfig.json") as file:
		return json.load(file)

def set_poster_config(user, new_data):
	with open(f"users/{user}/postconfig.json", "w") as file:
		json.dump(new_data, file, indent=4)

def get_all_configs():
	directory = "users"
	users = [name for name in os.listdir(directory) if os.path.isdir(os.path.join(directory, name))]
	configs = []
	for user in users:
		with open(f"users/{user}/postconfig.json") as file:
			configs.append(json.load(file))
	return configs