import json
import os
from configmanager import *


users = None

def update_users():
	global users
	directory = "users"
	users = [name for name in os.listdir(directory) if os.path.isdir(os.path.join(directory, name))]

def get_user_list():
	global users
	update_users()
	usernames = []
	for user in users:
		new_item = {
			"dir" : user,
			"username" : get_username_api_id_api_hash(user)[0]
		}
		usernames.append(new_item)
	return usernames




update_users()
print(get_user_list())