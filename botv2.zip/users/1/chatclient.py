from openai import OpenAI
import os
import json


def get_current_key():
    cwd = os.getcwd()
    # Go back two directories
    grandparent_dir = os.path.dirname(os.path.dirname(cwd))
    config_path = os.path.join(grandparent_dir, 'config.json')
    with open(config_path) as file:
        data = json.load(file)
    return data["api-key"]



client = OpenAI(
    api_key=get_current_key(),
)


def chat_with_client(messages_log):
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=messages_log,
        max_tokens=150
    )

    message = response.choices[0].message.content
    return message

