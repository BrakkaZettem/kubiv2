import json

chat_info = None

def load_chat_data():
	global chat_info
	with open("chat_log.json") as file:
		chat_info = json.load(file)

def save_chat_data():
    global chat_info
    with open("chat_log.json", "w") as file:
        json.dump(chat_info, file, indent=4)

#0 = false, 1 = true, 2 = user doesnt exist
def get_chat_mute_status(username):
	global chat_info
	load_chat_data()
	for chat in chat_info:
		if chat["username"] == username:
			return int(chat["muted"])
	return 2

def toggle_mute(username):
	global chat_info
	load_chat_data()
	for chat in chat_info:
		if chat["username"] == username:
			chat["muted"] = not chat["muted"]
			save_chat_data()
			return True
	return False


def get_chat_log(username):
	global chat_info
	load_chat_data()
	for chat in chat_info:
		if chat["username"] == username:
			return chat["session_content"]
	return None

def make_new_chat(username):
	global chat_info
	load_chat_data()
	new_chat = 	{
		"muted": False,
		"username" : username,
		"session_content": []
	}
	chat_info.append(new_chat)
	save_chat_data()

def append_to_chat(username, role, message):
	print("uessss")
	global chat_info
	load_chat_data()
	new_chat = {
                "role": role,
                "content": message
            }
	print(new_chat)
	for chat in chat_info:
		if username == chat["username"]:
			chat["session_content"].append(new_chat)
			save_chat_data()
			return True
	return False


