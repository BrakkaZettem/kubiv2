import json
config = None

def load_config_data():
	global config
	with open("config.json") as file:
		config = json.load(file)

def save_config_data():
    global config
    with open("config.json", "w") as file:
        json.dump(config, file, indent=4)

def get_username_api_id_api_hash():
	global config
	load_config_data()
	return (config["username"], config["api_id"], config["api_hash"])

def get_payment_info():
	global config
	load_config_data()
	return config["payments"]

def set_payment_info(new_payment_info):
	global config
	load_config_data()
	config["payments"] = new_payment_info
	save_config_data()


#[btc], [ltc], [eth], [paypal], [price]
def get_default_response_info():
	global config
	load_config_data()
	temp_default_msg = config["responder"]["default_message"]
	default_msg = temp_default_msg.replace("[btc]", get_payment_info()["bitcoin"]).replace("[ltc]", get_payment_info()["litecoin"]).replace("[eth]", get_payment_info()["ethereum"]).replace("[paypal]", get_payment_info()["paypal"]).replace("[price]", get_payment_info()["price"])
	return config["responder"]["default_message"]

def set_efault_response_info(new_message):
	global config
	load_config_data()
	config["responder"]["default_message"] = new_message
	save_config_data()


