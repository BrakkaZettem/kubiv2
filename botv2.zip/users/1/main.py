from chatclient import *
from chatmanager import *
from configmanager import *
from telethon import TelegramClient, events
import time

user_info = get_username_api_id_api_hash()

client = TelegramClient(user_info[0], user_info[1], user_info[2])

#await client.send_message(sender_id, response_message)

last_message_time = {}

@client.on(events.NewMessage)
async def handler(event):
    global last_message_time
    if event.is_private:
        sender_id = event.sender_id
        last_message_time[sender_id] = time.time()
        current_time = time.time()
        print("hello1")
        await asyncio.sleep(6)
        print("hello2")
        print(current_time)
        print(last_message_time[sender_id])
        if int(current_time) == int(last_message_time[sender_id]):
            print("hello3")
            sender_status = get_chat_mute_status(sender_id)
            if sender_status == 2:
                make_new_chat(sender_id)
                append_to_chat(sender_id, "system", get_default_response_info())
            sender_status = get_chat_mute_status(sender_id)
            if sender_status == 0:
                append_to_chat(sender_id, "user", event.text)
                current_chat = get_chat_log(sender_id)
                chat_result = chat_with_client(current_chat)
                append_to_chat(sender_id, "system", chat_result)
                await event.respond(chat_result)

            print(f"Received a message from {sender_id}: {event.text}")

async def main():
    # Start the client
    await client.start()

    print("Listening for incoming messages...")
    # Keep the client running to listen for events
    await client.run_until_disconnected()

# Running the main function in an asyncio event loop
import asyncio
asyncio.run(main())